# SCCM
Contains Scripts related to Configuration Manager
